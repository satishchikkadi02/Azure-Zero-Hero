# Delete Everything

```
az group delete --name keyvault-demo
```

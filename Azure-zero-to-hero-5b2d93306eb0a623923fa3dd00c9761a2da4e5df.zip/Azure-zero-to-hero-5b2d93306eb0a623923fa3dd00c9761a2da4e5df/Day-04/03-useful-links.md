# References

### Azure Virtual Machine Series 
https://azure.microsoft.com/en-in/pricing/details/virtual-machines/series/

### Jenkins Installation Steps
https://github.com/iam-veeramalla/Jenkins-Zero-To-Hero

### Download Git Bash
https://git-scm.com/downloads

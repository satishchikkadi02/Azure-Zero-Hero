# Install Azure CLI

### Installation Overview
https://learn.microsoft.com/en-us/cli/azure/install-azure-cli

### Install on Windows
https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli

### Install on Linux
https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt

### Install on Mac
https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-macos
